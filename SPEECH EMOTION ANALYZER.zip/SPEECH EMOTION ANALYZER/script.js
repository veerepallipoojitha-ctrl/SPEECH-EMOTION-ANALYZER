const SpeechRecognition =
    window.SpeechRecognition ||
    window.webkitSpeechRecognition;

let recognition;


const emotionWords = {

    happy: [
        "happy",
        "happiness",
        "joy",
        "joyful",
        "excited",
        "wonderful",
        "amazing",
        "great",
        "excellent",
        "love",
        "lovely",
        "fun",
        "laugh",
        "laughing",
        "smile",
        "smiling",
        "fantastic"
    ],

    sad: [
        "sad",
        "sadness",
        "unhappy",
        "cry",
        "crying",
        "tears",
        "lonely",
        "alone",
        "depressed",
        "hurt",
        "pain",
        "miss",
        "missing",
        "sorry",
        "disappointed"
    ],

    angry: [
        "angry",
        "anger",
        "hate",
        "hated",
        "furious",
        "annoyed",
        "annoying",
        "mad",
        "rage",
        "rude",
        "stupid",
        "frustrated",
        "frustration"
    ],

    fearful: [
        "afraid",
        "fear",
        "scared",
        "terrified",
        "danger",
        "dangerous",
        "worried",
        "worry",
        "nervous",
        "panic",
        "anxious",
        "anxiety"
    ]

};


if (SpeechRecognition) {

    recognition = new SpeechRecognition();

    recognition.continuous = false;

    recognition.interimResults = false;

    recognition.lang = "en-US";


    recognition.onstart = function () {

        document.getElementById("status").innerText =
            "🎤 Listening...";

    };


    recognition.onresult = function (event) {

        const transcript =
            event.results[0][0].transcript;


        document.getElementById("speechText").value =
            transcript;


        document.getElementById("status").innerText =
            "✅ Speech recognized.";

    };


    recognition.onerror = function (event) {

        document.getElementById("status").innerText =
            "Error: " + event.error;

    };


    recognition.onend = function () {

        document.getElementById("status").innerText =
            "Recognition stopped.";

    };

}


function startRecognition() {

    if (!recognition) {

        alert(
            "Speech recognition is not supported. Please use Google Chrome."
        );

        return;

    }


    try {

        recognition.start();

    }
    catch (error) {

        console.log(error);

    }

}


function stopRecognition() {

    if (recognition) {

        try {

            recognition.stop();

        }
        catch (error) {

            console.log(error);

        }

    }

}


function analyzeEmotion() {

    const text =
        document
            .getElementById("speechText")
            .value
            .toLowerCase()
            .trim();


    const result =
        document.getElementById("emotionResult");


    if (text === "") {

        result.innerHTML =
            "Please speak something first.";

        return;

    }


    const words =
        text.match(/\b[\w']+\b/g) || [];


    const scores = {

        happy: 0,

        sad: 0,

        angry: 0,

        fearful: 0

    };


    words.forEach(word => {

        if (emotionWords.happy.includes(word)) {
            scores.happy++;
        }

        if (emotionWords.sad.includes(word)) {
            scores.sad++;
        }

        if (emotionWords.angry.includes(word)) {
            scores.angry++;
        }

        if (emotionWords.fearful.includes(word)) {
            scores.fearful++;
        }

    });


    let emotion = "Neutral";

    let emoji = "😐";

    let highestScore = 0;


    for (const type in scores) {

        if (scores[type] > highestScore) {

            highestScore =
                scores[type];

            emotion =
                type;

        }

    }


    if (emotion === "happy") {
        emoji = "😊";
    }

    else if (emotion === "sad") {
        emoji = "😢";
    }

    else if (emotion === "angry") {
        emoji = "😠";
    }

    else if (emotion === "fearful") {
        emoji = "😨";
    }


    emotion =
        emotion.charAt(0).toUpperCase() +
        emotion.slice(1);


    result.innerHTML = `

        ${emoji}
        <br>

        Detected Emotion:
        <strong>${emotion}</strong>

        <br><br>

        <small>
            Happy: ${scores.happy}
            |
            Sad: ${scores.sad}
            |
            Angry: ${scores.angry}
            |
            Fearful: ${scores.fearful}
        </small>

    `;

}